# Atlas Pro v2 — دليل الإعداد

## الملفات
- `index.html` — التطبيق الكامل
- `sw.js` — Service Worker للعمل أوفلاين
- `manifest.json` — PWA manifest

---

## إعداد Firebase (مطلوب للمزامنة)

1. اذهب إلى https://console.firebase.google.com
2. أنشئ مشروع جديد
3. فعّل **Firestore Database** (ابدأ بـ test mode)
4. فعّل **Authentication > Google Sign-in**
5. اذهب إلى **Project Settings > Your Apps > Add Web App**
6. انسخ الـ config وضعها في `index.html` مكان القيم الـ placeholder:

```javascript
const firebaseConfig = {
  apiKey:            "AIza...",
  authDomain:        "my-project.firebaseapp.com",
  projectId:         "my-project",
  storageBucket:     "my-project.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123...:web:abc..."
};
```

---

## إعداد Google Drive (اختياري — لتخزين الصور)

1. اذهب إلى https://console.cloud.google.com
2. اختر نفس مشروع Firebase
3. APIs & Services > Credentials > Create OAuth 2.0 Client ID
4. Application type: **Web application**
5. Authorized origins: أضف رابط موقعك (مثلاً https://yoursite.com)
6. انسخ Client ID وضعه في `index.html`:

```javascript
window.GDRIVE_CLIENT_ID = "123456-abc.apps.googleusercontent.com";
```

---

## Firestore Security Rules

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

---

## النشر

### خيار 1: Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
firebase deploy
```

### خيار 2: أي استضافة ثابتة
ارفع الملفات الثلاثة على أي استضافة تدعم HTTPS.

---

## الميزات الجديدة في v2

- ✅ أقسام مخصصة بالكامل (أضف، احذف، عدّل)
- ✅ خانات مخصصة لكل قسم (نص، رقم، تاريخ، قائمة)
- ✅ مزامنة تلقائية مع Firebase
- ✅ يعمل أوفلاين مع IndexedDB persistence
- ✅ queue للعمليات عند انقطاع النت
- ✅ تصدير/استيراد JSON
- ✅ Google Drive: يُنشئ مجلدات تلقائياً للأقسام والماركات
- ✅ إدارة أنواع المخططات (أضف/احذف)
- ✅ تعديل المخططات الموجودة
- ✅ بحث شامل (اسم، ماركة، نوع، موديل، خانات مخصصة)
- ✅ PWA مع Service Worker محسّن
